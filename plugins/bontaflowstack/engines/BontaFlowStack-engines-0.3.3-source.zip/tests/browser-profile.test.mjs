import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {chromium} from 'playwright';
import {BrowserSession} from '../src/browser-session.mjs';

test('browser launches in a restricted workspace and retains task state outside Chromium runtime profiles',async()=>{
  const temporary=path.resolve('.tmp');fs.mkdirSync(temporary,{recursive:true});
  const root=fs.mkdtempSync(path.join(temporary,'bfs-profile-'));
  const folder=path.join(root,...Array(6).fill('long project and session directory'),'task-one');
  fs.mkdirSync(folder,{recursive:true});
  const requests=[];
  const server=http.createServer((req,res)=>{
    requests.push(req.headers.cookie || '');
    res.setHeader('content-type','text/html');
    res.end('<title>Profile acceptance</title><button onclick="this.textContent=\'Selected\'">Choose</button>');
  });
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const url=`http://127.0.0.1:${server.address().port}/`;
  let session=new BrowserSession(chromium,folder),other;
  try {
    await session.run(['goto',url],root);
    assert.match(await session.run(['snapshot','-i'],root),/Choose/);
    await session.run(['click','button'],root);
    assert.match(await session.run(['text'],root),/Selected/);
    await session.context.addCookies([{name:'session',value:'kept',url,httpOnly:true},
      {name:'persistent',value:'kept',url,httpOnly:true,expires:Math.floor(Date.now()/1000)+3600}]);
    await session.current.evaluate(async()=>{
      localStorage.setItem('local','kept');sessionStorage.setItem('tab','kept');
      await new Promise((resolve,reject)=>{
        const open=indexedDB.open('bfs-profile',1);
        open.onupgradeneeded=()=>open.result.createObjectStore('values');
        open.onerror=()=>reject(open.error);
        open.onsuccess=()=>{const db=open.result,tx=db.transaction('values','readwrite');tx.objectStore('values').put('kept','key');tx.oncomplete=()=>{db.close();resolve();};tx.onerror=()=>reject(tx.error);};
      });
    });
    await session.close();
    let before=requests.length;
    await session.launch();
    assert.match(requests[before],/session=kept/,'session cookie must precede same-service navigation');
    await session.close();
    session=new BrowserSession(chromium,folder);
    before=requests.length;
    await session.launch();
    assert.match(requests[before],/persistent=kept/,'persistent cookie must precede restored navigation');
    assert.doesNotMatch(requests[before],/session=kept/,'session cookies expire with the service');
    assert.equal(await session.current.evaluate(()=>localStorage.getItem('local')),'kept');
    assert.equal(await session.current.evaluate(()=>sessionStorage.getItem('tab')),'kept');
    assert.equal(await session.current.evaluate(()=>new Promise((resolve,reject)=>{const open=indexedDB.open('bfs-profile');open.onsuccess=()=>{const db=open.result,read=db.transaction('values').objectStore('values').get('key');read.onsuccess=()=>{db.close();resolve(read.result);};read.onerror=()=>reject(read.error);};open.onerror=()=>reject(open.error);})), 'kept');
    other=new BrowserSession(chromium,path.join(root,'task-two'));
    await other.run(['goto',url],root);
    assert.equal(await other.current.evaluate(()=>localStorage.getItem('local')),null);
    assert.equal((await other.context.cookies()).length,0);
    const screenshot=process.env.BFS_PROFILE_SCREENSHOT;
    if(screenshot)await session.current.screenshot({path:screenshot});
  } finally {
    await other?.close();await session.close();
    await new Promise(resolve=>server.close(resolve));
  }
});
