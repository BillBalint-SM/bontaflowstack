import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {BrowserSession} from '../src/browser-session.mjs';

function fixture(t) {
  const root=path.resolve('.tmp');fs.mkdirSync(root,{recursive:true});
  const folder=fs.mkdtempSync(path.join(root,'bfs-state-'));
  t.after(()=>fs.rmSync(folder,{recursive:true,force:true}));
  const sessionCookie={name:'session',value:'private',domain:'example.test',path:'/',expires:-1};
  const persistentCookie={...sessionCookie,name:'persistent',expires:2000000000};
  const calls=[],page={on(){},isClosed:()=>false,url:()=> 'about:blank',evaluate:async()=>({session:{},scroll:[0,0]})};
  const context={setDefaultTimeout(){},setDefaultNavigationTimeout(){},on(){},pages:()=>[page],
    cookies:async()=>[sessionCookie,persistentCookie],addCookies:async cookies=>calls.push(['cookies',cookies]),
    storageState:async options=>{assert.equal(options.indexedDB,true);return {cookies:[sessionCookie,persistentCookie],origins:[]};},
    close:async()=>calls.push(['context.close'])};
  const browser={newContext:async options=>{calls.push(['context',options]);return context;},close:async()=>calls.push(['browser.close'])};
  const chromium={launch:async options=>{calls.push(['launch',options]);return browser;}};
  return {folder,calls,context,browser,chromium,sessionCookie,persistentCookie};
}

test('task snapshot retains durable cookies, while session cookies stay within the service',async t=>{
  const f=fixture(t),session=new BrowserSession(f.chromium,f.folder);
  await session.launch();await session.close();
  const saved=JSON.parse(fs.readFileSync(path.join(f.folder,'tabs.json'),'utf8'));
  assert.deepEqual(saved.storage.cookies,[f.persistentCookie]);
  assert.equal(f.calls[0][1].chromiumSandbox,true);
  assert.equal('userDataDir' in f.calls[0][1],false);
  await session.launch();
  assert.deepEqual(f.calls.filter(c=>c[0]==='cookies').at(-1)[1],[f.sessionCookie,f.persistentCookie]);
  await session.close();f.calls.length=0;
  const resumed=new BrowserSession(f.chromium,f.folder);
  await resumed.launch();
  assert.deepEqual(f.calls.find(c=>c[0]==='context')[1].storageState.cookies,[f.persistentCookie]);
  assert.equal(f.calls.some(c=>c[0]==='cookies'),false);
  await resumed.close();
});

test('failed state capture preserves the last snapshot and closes owned resources',async t=>{
  const f=fixture(t),session=new BrowserSession(f.chromium,f.folder);
  await session.launch();await session.save();
  const file=path.join(f.folder,'tabs.json'),before=fs.readFileSync(file);
  f.context.storageState=async()=>{throw new Error('capture failed');};
  await assert.rejects(session.close(),/capture failed/);
  assert.deepEqual(fs.readFileSync(file),before);
  assert.deepEqual(f.calls.slice(-2).map(c=>c[0]),['context.close','browser.close']);
  assert.equal(session.context,null);
});

test('a failed restore closes the launched browser without rewriting saved state',async t=>{
  const f=fixture(t),session=new BrowserSession(f.chromium,f.folder);
  const file=path.join(f.folder,'tabs.json'),before=JSON.stringify({schema:1,tabs:[{url:'https://example.test/'}]});
  fs.writeFileSync(file,before);
  session.restore=async()=>{throw new Error('restore failed');};
  await assert.rejects(session.launch(),/restore failed/);
  assert.equal(fs.readFileSync(file,'utf8'),before);
  assert.equal(f.calls.at(-1)[0],'browser.close');
  assert.equal(session.context,null);
});

test('an oversized browser snapshot cannot replace the last readable snapshot',async t=>{
  const f=fixture(t),session=new BrowserSession(f.chromium,f.folder);
  await session.launch();await session.save();
  const file=path.join(f.folder,'tabs.json'),before=fs.readFileSync(file);
  f.context.storageState=async()=>({cookies:[],origins:[{origin:'https://example.test',localStorage:[{name:'large',value:'x'.repeat(8*1024*1024)}]}]});
  await assert.rejects(session.close(),/8 MiB/);
  assert.deepEqual(fs.readFileSync(file),before);
});
