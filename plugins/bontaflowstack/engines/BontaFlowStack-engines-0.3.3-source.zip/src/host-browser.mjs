import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { BrowserSession } from './browser-session.mjs';
export { help } from './browser.mjs';

process.env.PLAYWRIGHT_BROWSERS_PATH=fileURLToPath(new URL('../.browsers',import.meta.url));
const {chromium}=await import('playwright');
export const createBrowser=folder=>new BrowserSession(chromium,path.resolve(folder));
export const render=(await import('./render.mjs')).render;
