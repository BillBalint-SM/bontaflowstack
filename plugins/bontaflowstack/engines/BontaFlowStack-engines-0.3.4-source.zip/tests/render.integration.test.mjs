import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {render} from '../src/render.mjs';

test('native sandboxed render saves a PNG at the requested viewport and a PDF',async t=>{
  const folder=fs.mkdtempSync(path.join(os.tmpdir(),'bfs-render-'));
  t.after(()=>fs.rmSync(folder,{recursive:true,force:true}));
  fs.writeFileSync(path.join(folder,'page.html'),'<!doctype html><html lang="en"><meta charset="utf-8"><title>Render fixture</title><h1>Portable engine</h1></html>');
  const result=await render(['page.html','--width','640','--height','480','--screenshot','page.png','--pdf','page.pdf'],folder);
  assert.equal(result.status,'completed');assert.deepEqual(result.errors,[]);assert.equal(result.horizontalOverflow,false);
  const png=fs.readFileSync(result.screenshot);assert.equal(png.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
  assert.equal(png.readUInt32BE(16),640);assert.equal(png.readUInt32BE(20),480);
  assert.equal(fs.readFileSync(result.pdf).subarray(0,4).toString(),'%PDF');
});
