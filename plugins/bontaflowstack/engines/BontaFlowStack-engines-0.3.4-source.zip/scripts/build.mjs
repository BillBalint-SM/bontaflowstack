#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';

const root=fileURLToPath(new URL('../',import.meta.url)),args=process.argv.slice(2);
try {
  if(args.some(arg=>!['--install','--install-browser'].includes(arg)))throw new Error('Use --install and/or --install-browser');
  if(Number(process.versions.node.split('.')[0])<24)throw new Error('Node.js 24 or newer is required');
  if(!['win32-x64','linux-x64','linux-arm64','darwin-x64','darwin-arm64'].includes(`${process.platform}-${process.arch}`))throw new Error(`Unsupported engine target: ${process.platform}-${process.arch}`);
  const env={...process.env,PLAYWRIGHT_BROWSERS_PATH:path.join(root,'.browsers'),PATH:`${path.dirname(process.execPath)}${path.delimiter}${process.env.PATH || ''}`};
  const run=(command,argv)=>{
    const result=spawnSync(command,argv,{cwd:root,env,stdio:'inherit',windowsHide:true});
    if(result.error)throw result.error;
    if(result.status!==0)throw new Error(`Engine build command failed (${result.status ?? result.signal}): ${command}`);
  };
  if(args.includes('--install')) {
    const npmCandidates=[process.env.npm_execpath && path.join(path.dirname(process.env.npm_execpath),'npm-cli.js'),
      path.join(path.dirname(process.execPath),'node_modules/npm/bin/npm-cli.js'),
      path.resolve(path.dirname(process.execPath),'../lib/node_modules/npm/bin/npm-cli.js')].filter(Boolean);
    const npm=npmCandidates.find(file=>fs.statSync(file,{throwIfNoEntry:false})?.isFile());
    if(npm)run(process.execPath,[npm,'ci','--ignore-scripts','--no-audit','--no-fund']);
    else if(process.platform!=='win32')run('npm',['ci','--ignore-scripts','--no-audit','--no-fund']);
    else throw new Error('Install Node.js with npm before building the engine');
  }
  if(args.includes('--install-browser'))run(process.execPath,[path.join(root,'node_modules/playwright/cli.js'),'install','chromium']);
  run(process.execPath,['--input-type=module','-e',"import {chromium} from 'playwright'; const browser=await chromium.launch({headless:true,chromiumSandbox:true}); await browser.close();"]);
  run(process.execPath,[path.join(root,'scripts/manifest.mjs')]);
} catch(error) {process.stderr.write(`${error.message}\n`);process.exitCode=1;}
