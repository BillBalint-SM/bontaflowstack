[CmdletBinding()]
param([switch]$Install, [switch]$InstallBrowser)
$ErrorActionPreference = 'Stop'
$buildArgs = @()
if ($Install) { $buildArgs += '--install' }
if ($InstallBrowser) { $buildArgs += '--install-browser' }
& node (Join-Path $PSScriptRoot 'build.mjs') @buildArgs
exit $LASTEXITCODE
